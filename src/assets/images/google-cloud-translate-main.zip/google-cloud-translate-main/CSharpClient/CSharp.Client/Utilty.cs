﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TranlationApp
{
    public class Utilty
    {
        // You need to add your Google cloud api key to authorize the request
        // You can get it from your authorized google cloud account
        public const string apiKey = "";
    }
}
