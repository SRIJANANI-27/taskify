export const environment = {
  production: true,
  apiKey:'<provide your google cloud api key here>'
};
