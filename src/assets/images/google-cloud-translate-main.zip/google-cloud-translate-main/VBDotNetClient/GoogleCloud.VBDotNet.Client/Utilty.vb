﻿Public Class Utilty

    Public Const GoogleCloudApiKey = "<Your Google cloud translate api key>"
End Class
